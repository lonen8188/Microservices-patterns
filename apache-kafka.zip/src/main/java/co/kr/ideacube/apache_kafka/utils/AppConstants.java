package co.kr.ideacube.apache_kafka.utils;

public class AppConstants {
    public static final String TOPIC_NAME = "mytopic";
    public static final String GROUP_ID = "mygroup";
}
